dbPassword = 'mongodb://qwerty12:qwerty12@cluster0-shard-00-00.53odv.mongodb.net:27017,cluster0-shard-00-01.53odv.mongodb.net:27017,cluster0-shard-00-02.53odv.mongodb.net:27017/myFirstDatabase?ssl=true&replicaSet=atlas-29z6uq-shard-0&authSource=admin&retryWrites=true&w=majority';
module.exports = {
    mongoURI: dbPassword
};